import boto3

session = boto3.Session(aws_access_key_id='AKIA5IXLCR4VK4EMIFPO',aws_secret_access_key='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')




my_client=session.client('elb',region_name='us-east-2')
response = my_client.describe_load_balancers()

for loadbalancer in response['LoadBalancerDescriptions']:

    print (loadbalancer['DNSName'])
